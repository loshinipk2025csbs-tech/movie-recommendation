# Frame — Movie Recommendation Prototype

A small, responsive movie discovery website with genre and mood filters, search, sorting, saved movies, and a detail view. The Python server uses only the standard library.

## Run locally

1. Install Python 3 if it is not already installed.
2. Open a terminal in this folder.
3. Run:

   ```bash
   python app.py
   ```

4. Visit <http://127.0.0.1:8000>.

## Files

- `index.html` — website interface and browser-side interactions
- `app.py` — local web server

This is a front-end prototype. Account actions, reviews, recommendations, and trailer playback are demo interactions and do not connect to a database or external APIs.
